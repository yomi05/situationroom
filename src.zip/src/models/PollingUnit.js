import mongoose from 'mongoose';

const PollingUnitSchema = new mongoose.Schema({
  state:            { type: String },
  lga:              { type: String },
  registrationArea: { type: String },
  pollingUnit:      { type: String }
}, { timestamps: true });

export default mongoose.models.PollingUnit || mongoose.model('PollingUnit', PollingUnitSchema);

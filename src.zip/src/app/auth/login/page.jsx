'use client';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await signIn('credentials', {
      ...form,
      redirect: false,
    });

    if (res.ok) router.push('/dashboard');
    else setError('Invalid email or password');
  };

  return (
    <div className="min-h-screen grid grid-cols-1 md:grid-cols-2">
      {/* Left Panel */}
      <div className="bg-[#245B9E] text-white flex flex-col justify-center items-center p-8">
        <h1 className="text-4xl font-bold mb-6 text-center">Hi, Welcome Back!</h1>
        <Link
          href="/incident-report"
          className="bg-red-600 hover:bg-red-500 text-white px-6 py-2 rounded-full font-medium"
        >
          📢 Report an Incident
        </Link>
      </div>

      {/* Right Panel */}
      <div className="flex flex-col justify-center items-center p-8 bg-white relative">
        {/* Logo */}
        <div className="absolute top-6 right-6">
          <Image src="/logo.png" alt="SituationRoom Logo" width={180} height={40} />
        </div>

        <form onSubmit={handleSubmit} className="w-full max-w-sm mt-12 md:mt-0">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Sign In</h2>
          <p className="text-sm text-gray-500 mb-6">
            New user? <Link href="/auth/register" className="text-[#245B9E] font-medium">Create an Account</Link>
          </p>

          {error && <p className="text-red-500 text-sm mb-2">{error}</p>}

          <label className="block text-sm font-medium mb-1">Login with your email</label>
          <input
            type="email"
            placeholder="Enter your email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full px-3 py-2 border rounded-md mb-4 focus:ring-2 focus:ring-[#245B9E]"
            required
          />

          <div className="relative mb-6">
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-[#245B9E]"
              required
            />
            <span
              className="absolute right-3 top-2.5 text-gray-500 cursor-pointer"
              onClick={() => setShowPassword(!showPassword)}
            >
              👁
            </span>
          </div>

          <div className="flex justify-between text-sm mb-4">
            <label className="flex items-center gap-2">
              <input type="checkbox" className="accent-[#245B9E]" /> Remember me
            </label>
            <Link href="/auth/forgot-password" className="text-pink-500 hover:underline">
              Forgot Password?
            </Link>
          </div>

          <button
            type="submit"
            className="w-full bg-[#245B9E] hover:bg-[#1a3e70] text-white py-2 rounded-md font-semibold"
          >
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
}
